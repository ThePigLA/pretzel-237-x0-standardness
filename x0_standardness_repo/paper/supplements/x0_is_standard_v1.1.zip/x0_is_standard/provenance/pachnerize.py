"""Replace non-Pachner steps (2-0 moves, edge collapses) of a loop-erased path by explicit Pachner paths.
For a step a -> b, bidirectional BFS in the Pachner graph (1-5, 2-4, 3-3, 4-2, 5-1 moves, all guarded Regina
pachner() calls on canonical triangulations) with a size cap, increasing the cap until the two searches meet.
Every edge of the output is a single Pachner move applied to fromIsoSig(state) giving the next state's isoSig.
Usage: pachnerize.py LOOP_ERASED.json OUT.json"""
import regina, json, sys, time, warnings
from collections import deque
warnings.filterwarnings('ignore')
GET = {'P0': 'vertex', 'P1': 'edge', 'P2': 'triangle', 'P3': 'tetrahedron', 'P4': 'pentachoron'}
CNT = {'P0': 'countVertices', 'P1': 'countEdges', 'P2': 'countTriangles', 'P3': 'countTetrahedra', 'P4': 'size'}
DELTA = {'P0': -4, 'P1': -2, 'P2': 0, 'P3': 2, 'P4': 4}

def neighbours(sig, cap):
    A = regina.Triangulation4.fromIsoSig(sig); n = A.size(); out = []
    for code in ('P1', 'P0', 'P2', 'P3', 'P4'):
        if n + DELTA[code] > cap: continue
        for i in range(getattr(A, CNT[code])()):
            f = getattr(A, GET[code])(i)
            if not A.hasPachner(f): continue
            U = regina.Triangulation4(A); assert U.pachner(getattr(U, GET[code])(i))
            out.append((U.isoSig(), code, i))
    return out

def single_pachner(a, b, cap=10**9):
    for s, code, i in neighbours(a, cap):
        if s == b: return code, i
    return None

def bibfs(a, b, cap, max_nodes=400000):
    if a == b: return []
    pa = {a: None}; pb = {b: None}; qa = deque([a]); qb = deque([b])
    while qa and qb and len(pa) + len(pb) < max_nodes:
        for (q, p, other) in ((qa, pa, pb), (qb, pb, pa)):
            for _ in range(len(q)):
                x = q.popleft()
                for y, code, i in neighbours(x, cap):
                    if y in p: continue
                    p[y] = (x, code, i); q.append(y)
                    if y in other:
                        # path a .. y (forward via pa) then y .. b (via pb, reversed)
                        left = []; z = y
                        while pa.get(z) is not None: x0, c0, i0 = pa[z]; left.append((x0, c0, i0, z)); z = x0
                        left.reverse()
                        right = []; z = y
                        while pb.get(z) is not None:
                            x0, _, _ = pb[z]           # edge x0 -> z found from b's side; we need z -> x0 forward
                            m = single_pachner(z, x0); assert m is not None
                            right.append((z, m[0], m[1], x0)); z = x0
                        return left + right
    return None

if __name__ == '__main__':
    src, out = sys.argv[1], sys.argv[2]
    d = json.load(open(src)); steps = d['steps']; res = []; t0 = time.time(); conv = 0
    for k, (a, code, face, b) in enumerate(steps):
        if code.startswith('P'): res.append((a, code, face, b)); continue
        na = regina.Triangulation4.fromIsoSig(a).size(); path = None
        for h, lim in ((0, 30000), (2, 150000), (4, 400000), (6, 1000000)):
            path = bibfs(a, b, max(na, regina.Triangulation4.fromIsoSig(b).size()) + h, max_nodes=lim)
            if path is not None: break
        assert path is not None, f'step {k}: no Pachner path found for {code}'
        res += path; conv += 1
        print(f'  step {k} {code}: replaced by {len(path)} Pachner moves (cap +{h}) [{time.time()-t0:.0f}s]', flush=True)
    # independent check of the whole output
    for a, code, i, b in res:
        T = regina.Triangulation4.fromIsoSig(a); f = getattr(T, GET[code])(i)
        assert T.pachner(f, True, True) and T.isoSig() == b
    for (a1, _, _, b1), (a2, _, _, b2) in zip(res, res[1:]): assert b1 == a2
    json.dump({'start': res[0][0] if res else d['start'], 'end': res[-1][3] if res else d['end'], 'steps': res}, open(out, 'w'))
    from collections import Counter
    print(f'converted {conv} non-Pachner steps; pure Pachner path of {len(res)} moves {dict(Counter(s[1] for s in res))};',
          'start', res[0][0], 'end', res[-1][3], f'[{time.time()-t0:.0f}s]')
