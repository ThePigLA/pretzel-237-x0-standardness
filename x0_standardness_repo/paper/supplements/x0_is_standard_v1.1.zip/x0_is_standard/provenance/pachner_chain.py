"""Pachner-only version of the Burke-Burton-Spreer walk chain: 2-0 moves are replaced by 4-2 moves and edge
collapses by 5-1 moves; 1-5, 2-4, 3-3 as in main.cc.  Every move is a guarded Regina Pachner move.
Usage: pachner_chain.py NAME START SECONDS SEED"""
import regina, random, json, sys, time, math, warnings
warnings.filterwarnings('ignore')
def beta(n, bal, sc): a = math.exp(sc * (bal - n)); return a / (1 + a)
def perform(T, rng, xx, b, verts, log):
    v = T.countVertices()
    if v < verts:
        T.pachner(T.pentachoron(0), True, True); log.append(('P4', 0)); return True
    if v > verts:
        for i in range(T.countVertices()):
            if T.pachner(T.vertex(i), True, True): log.append(('P0', i)); return True
    if rng.random() > xx:
        for i in range(T.countTriangles()):
            if T.pachner(T.triangle(i), True, True): log.append(('P2', i)); return True
    if rng.random() > b:
        for i in range(T.countEdges()):
            if T.pachner(T.edge(i), True, True): log.append(('P1', i)); return True
    for i in range(T.countTetrahedra()):
        if T.pachner(T.tetrahedron(i), True, True): log.append(('P3', i)); return True
    return False
def step(T, rng, xx=0.1, bal=9, sc=1.0, tv=2, tp=6, max_steps=10**6):
    log = []
    for _ in range(max_steps):
        if not perform(T, rng, xx, beta(T.size(), bal, sc), tv, log): return None, log
        if T.countVertices() == tv and T.size() == tp: return T.isoSig(), log
    return None, log
def replay(start, log):
    T = regina.Triangulation4.fromIsoSig(start)
    for code, i in log:
        f = {'P0': T.vertex, 'P1': T.edge, 'P2': T.triangle, 'P3': T.tetrahedron, 'P4': T.pentachoron}[code](i)
        assert T.pachner(f, True, True), (code, i)
    return T.isoSig()
if __name__ == '__main__':
    name, start, secs, seed = sys.argv[1], sys.argv[2], float(sys.argv[3]), int(sys.argv[4])
    rng = random.Random(seed); T = regina.Triangulation4.fromIsoSig(start)
    first = {}; walks = 0; t0 = time.time(); logf = open(f'pchain_{name}_s{seed}.moves.jsonl', 'w')
    while time.time() - t0 < secs:
        e, log = step(T, rng)
        if e is None: print('walk failed'); break
        walks += 1; logf.write(json.dumps({'walk': walks, 'moves': log, 'end': e}) + '\n')
        first.setdefault(e, walks)
    logf.close()
    json.dump({'start': start, 'walks': walks, 'endpoints': first}, open(f'pchain_{name}_s{seed}.json', 'w'))
    print(name, walks, 'walks;', len(first), 'distinct 2-vertex 6-pentachoron triangulations', f'[{time.time()-t0:.0f}s]')
