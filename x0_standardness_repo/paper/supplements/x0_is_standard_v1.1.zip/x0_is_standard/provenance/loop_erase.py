"""Loop-erase a long move path.  Replays the moves, records the canonical isoSig after every move, erases loops in
the state sequence, then re-derives every remaining step as ONE move applied to the canonical triangulation
fromIsoSig(state_i) whose result has isoSig state_{i+1}.  Output: [(state_i, code, face, state_{i+1}), ...]."""
import regina, json, sys, warnings
warnings.filterwarnings('ignore')
FACE = {'P0': 'vertex', 'P1': 'edge', 'P2': 'triangle', 'P3': 'tetrahedron', 'P4': 'pentachoron',
        'Z1': 'edge', 'Z2': 'triangle', 'C': 'edge'}
def do(T, code, i):
    f = getattr(T, FACE[code])(i)
    if code[0] == 'P': return T.pachner(f, True, True)
    if code[0] == 'Z': return T.twoZeroMove(f, True, True)
    if code == 'C': return T.collapseEdge(f, True, True)
def states_along(start, moves):
    T = regina.Triangulation4.fromIsoSig(start); seq = [T.isoSig()]
    for code, i in moves:
        assert do(T, code, i); seq.append(T.isoSig())
    return seq
def erase(seq):
    out = []; pos = {}
    for s in seq:
        if s in pos:
            k = pos[s]
            for t in out[k + 1:]: del pos[t]
            out = out[:k + 1]
        else:
            pos[s] = len(out); out.append(s)
    return out
def one_move(a, b, codes=('P0', 'P1', 'P2', 'P3', 'P4', 'Z1', 'Z2', 'C')):
    A = regina.Triangulation4.fromIsoSig(a)
    n = {'vertex': A.countVertices(), 'edge': A.countEdges(), 'triangle': A.countTriangles(),
         'tetrahedron': A.countTetrahedra(), 'pentachoron': A.size()}
    for code in codes:
        for i in range(n[FACE[code]]):
            U = regina.Triangulation4(A)
            if do(U, code, i) and U.isoSig() == b: return (code, i)
    return None
if __name__ == '__main__':
    start, movesfile, out = sys.argv[1], sys.argv[2], sys.argv[3]
    moves = [tuple(m) for m in json.load(open(movesfile))]
    seq = states_along(start, moves); short = erase(seq)
    steps = []
    for a, b in zip(short, short[1:]):
        m = one_move(a, b); assert m is not None, 'no single move between consecutive states'
        steps.append((a, m[0], m[1], b))
    json.dump({'start': short[0], 'end': short[-1], 'steps': steps}, open(out, 'w'))
    from collections import Counter
    print(f'{len(moves)} moves -> {len(seq)} states -> loop-erased {len(short)} states, {len(steps)} single-move steps;',
          'move types', dict(Counter(s[1] for s in steps)), '; max size', max(regina.Triangulation4.fromIsoSig(s).size() for s in short))
