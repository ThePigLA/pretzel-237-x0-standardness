"""Chain of Burke-style walks: each walk ends at a 2-vertex 6-pentachoron triangulation and the next walk starts
there.  Records every distinct endpoint reached (with the walk number that first reached it) and the full move log,
so any endpoint has an explicit replayable path from the start.  Usage: chain.py NAME START_ISOSIG SECONDS SEED PHASE"""
import regina, random, json, sys, time
sys.path.insert(0, '/home/claude/x0/census')
from burke_walk import step
name, start, secs, seed, phase = sys.argv[1], sys.argv[2], float(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
xx, balance, scaling = (0.1, 9, 1.0) if phase == 1 else (0.1, 12, 0.9)
rng = random.Random(seed); T = regina.Triangulation4.fromIsoSig(start)
first = {T.isoSig(): 0}; walks = 0; moves = 0; t0 = time.time(); hist = []
logf = open(f'chain_{name}_s{seed}_p{phase}.moves.jsonl', 'w')
while time.time() - t0 < secs:
    e, log = step(T, rng, xx, balance, scaling, max_steps=10**6)
    if e is None: break
    walks += 1; moves += len(log)
    logf.write(json.dumps({'walk': walks, 'moves': log, 'end': e}) + '\n')
    if e not in first: first[e] = walks
    if walks % 2000 == 0: hist.append((walks, len(first), round(time.time() - t0)))
logf.close()
json.dump({'name': name, 'start': start, 'seed': seed, 'phase': phase, 'walks': walks, 'moves': moves,
           'distinct_endpoints': len(first), 'growth': hist, 'endpoints': first, 'seconds': round(time.time() - t0)},
          open(f'chain_{name}_s{seed}_p{phase}.json', 'w'))
print(name, 'seed', seed, 'phase', phase, ':', walks, 'walks,', len(first), 'distinct 2-vertex 6-pentachoron triangulations reached',
      f'[{time.time()-t0:.0f}s]')
