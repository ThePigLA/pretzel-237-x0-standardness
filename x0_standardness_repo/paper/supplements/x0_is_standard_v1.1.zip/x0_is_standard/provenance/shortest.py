"""Shortest certificate inside the visited-state graphs of the two chains.
Nodes: canonical isoSigs.  Edges: the recorded single moves (directed; Pachner edges also usable backwards).
Find X in (states reachable from G6 by recorded forward moves) and (states reachable from std6 by recorded forward
moves) minimizing the sum of BFS distances; output both forward paths as (state, code, face, next) steps, each
re-derived as one move on the canonical triangulation."""
import regina, json, sys, warnings
from collections import deque, defaultdict
sys.path.insert(0, '/home/claude/x0/census')
from loop_erase import do, one_move
warnings.filterwarnings('ignore')
def graph(start, moves):
    T = regina.Triangulation4.fromIsoSig(start); s = T.isoSig(); adj = defaultdict(set)
    for code, i in moves:
        assert do(T, code, i); t = T.isoSig()
        if t != s: adj[s].add((t, code))
        s = t
    return adj
def bfs(adj, src):
    dist = {src: 0}; par = {src: None}; q = deque([src])
    while q:
        x = q.popleft()
        for y, code in adj[x]:
            if y not in dist: dist[y] = dist[x] + 1; par[y] = x; q.append(y)
    return dist, par
def path(par, x):
    out = []
    while par[x] is not None: out.append((par[x], x)); x = par[x]
    return out[::-1]
c = json.load(open('/home/claude/x0/census/meet_certificate.json'))
A = graph(c['G6'], [tuple(m) for m in c['path_G6_to_meet']]); print('G6-side graph nodes', len(A), flush=True)
B = graph(c['std6'], [tuple(m) for m in c['path_std6_to_meet']]); print('std-side graph nodes', len(B), flush=True)
dA, pA = bfs(A, regina.Triangulation4.fromIsoSig(c['G6']).isoSig()); dB, pB = bfs(B, regina.Triangulation4.fromIsoSig(c['std6']).isoSig())
common = set(dA) & set(dB); X = min(common, key=lambda x: (dA[x] + dB[x], dA[x]))
print('meeting', X, 'distances', dA[X], dB[X], flush=True)
out = {}
for name, par in (('G6_to_X', pA), ('std6_to_X', pB)):
    steps = []
    for a, b in path(par, X):
        m = one_move(a, b); assert m is not None; steps.append((a, m[0], m[1], b))
    out[name] = steps
    from collections import Counter
    print(name, len(steps), 'steps', dict(Counter(s[1] for s in steps)), 'max size', max(regina.Triangulation4.fromIsoSig(s[3]).size() for s in steps), flush=True)
out['X'] = X
json.dump(out, open('/home/claude/x0/census/shortest_paths.json', 'w'))
