"""Python port of the random walk in Burke-Burton-Spreer's Dim4Census main.cc (perform/step), used to classify
6-pentachoron triangulations: walk until the triangulation again has targetVertices vertices and targetPentachora
pentachora, then merge start and endpoint.  Parameters as in main.cc (phase 1/2: xx=0.1, balance=2p-3, scaling=1.0;
phase 3: balance=2p, scaling=0.9).  Moves use the same guarded Regina calls and the same first-legal-face order.
Every move is logged so that an endpoint comes with an explicit replayable path."""
import regina, random, math, json, sys, time, warnings
warnings.filterwarnings('ignore')

def beta(n, balance, scaling):
    a = math.exp(scaling * (balance - n)); return a / (1 + a)

def perform(T, rng, xx, b, verts, lower, upper, log):
    v = T.countVertices()
    if v < verts:
        T.pachner(T.pentachoron(0), False, True); log.append(('P4', 0)); return True
    if v > verts:
        for i in range(T.countEdges()):
            if T.collapseEdge(T.edge(i), True, True): log.append(('C', i)); return True
    if rng.random() > xx and T.size() >= lower:
        for i in range(T.countTriangles()):
            if T.pachner(T.triangle(i), True, True): log.append(('P2', i)); return True
    if rng.random() > b and T.size() >= lower:
        for i in range(T.countEdges()):
            if T.twoZeroMove(T.edge(i), True, True): log.append(('Z1', i)); return True
        for i in range(T.countTriangles()):
            if T.twoZeroMove(T.triangle(i), True, True): log.append(('Z2', i)); return True
    if T.size() <= upper - 2:
        for i in range(T.countTetrahedra()):
            if T.pachner(T.tetrahedron(i), True, True): log.append(('P3', i)); return True
    else:
        for i in range(T.countTriangles()):
            if T.pachner(T.triangle(i), True, True): log.append(('P2', i)); return True
        for i in range(T.countEdges()):
            if T.twoZeroMove(T.edge(i), True, True): log.append(('Z1', i)); return True
        for i in range(T.countTriangles()):
            if T.twoZeroMove(T.triangle(i), True, True): log.append(('Z2', i)); return True
    for i in range(T.countTetrahedra()):
        if T.pachner(T.tetrahedron(i), True, True): log.append(('P3', i)); return True
    return False

def step(T, rng, xx, balance, scaling, tv=2, tp=6, lower=0, upper=9999, max_steps=10**7):
    log = []; st = 0
    while st < max_steps:
        st += 1
        if not perform(T, rng, xx, beta(T.size(), balance, scaling), tv, lower, upper, log): return None, log
        if T.countVertices() == tv and T.size() == tp: return T.isoSig(), log
    return None, log

def replay(start, log):
    T = regina.Triangulation4.fromIsoSig(start)
    for code, i in log:
        if code == 'P4': ok = T.pachner(T.pentachoron(i), False, True)
        elif code == 'C': ok = T.collapseEdge(T.edge(i), True, True)
        elif code == 'P2': ok = T.pachner(T.triangle(i), True, True)
        elif code == 'P3': ok = T.pachner(T.tetrahedron(i), True, True)
        elif code == 'Z1': ok = T.twoZeroMove(T.edge(i), True, True)
        elif code == 'Z2': ok = T.twoZeroMove(T.triangle(i), True, True)
        assert ok, (code, i)
    return T.isoSig()
