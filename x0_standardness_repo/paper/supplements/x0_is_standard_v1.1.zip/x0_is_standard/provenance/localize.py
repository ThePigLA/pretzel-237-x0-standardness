"""Convert each non-Pachner step a -> b of a path into explicit Pachner moves by a LOCAL search: every pentachoron
outside a radius-r neighbourhood of the 2-0 face is locked (Regina moves respect locks), and a BFS over Pachner moves
(2-4, 3-3, 4-2) with a size cap looks for b.  States are compared by lock-free isoSig.  Every found edge is then
re-derived as one Pachner move on the canonical (unlocked) triangulation fromIsoSig(state).
Usage: localize.py PATHS.json KEY OUT.json      (PATHS[KEY] is a list of (state, code, face, next) steps)"""
import regina, json, sys, time, warnings
from collections import deque
sys.path.insert(0, '/home/claude/x0/census')
from pachnerize import single_pachner, bibfs, GET
warnings.filterwarnings('ignore')
FACE = {'Z1': 'edge', 'Z2': 'triangle', 'C': 'edge'}
CNT = {'P1': 'countEdges', 'P2': 'countTriangles', 'P3': 'countTetrahedra'}
DELTA = {'P1': -2, 'P2': 0, 'P3': 2}

def region(A, code, idx, radius):
    f = getattr(A, FACE[code])(idx)
    R = {f.embedding(j).pentachoron().index() for j in range(f.degree())}
    for _ in range(radius):
        R |= {A.pentachoron(p).adjacentPentachoron(k).index() for p in list(R) for k in range(5)
              if A.pentachoron(p).adjacentPentachoron(k) is not None}
    return R

def local_bfs(a, code, idx, b, radius, h, max_nodes):
    A = regina.Triangulation4.fromIsoSig(a); R = region(A, code, idx, radius)
    for p in A.pentachora():
        if p.index() not in R: p.lock()
    cap = A.size() + h; start = A.isoSig_LockFree()
    par = {start: None}; objs = deque([(A, start)])
    while objs and len(par) < max_nodes:
        T, s = objs.popleft()
        for c in ('P1', 'P2', 'P3'):
            if T.size() + DELTA[c] > cap: continue
            for i in range(getattr(T, CNT[c])()):
                if not T.hasPachner(getattr(T, GET[c])(i)): continue
                U = regina.Triangulation4(T); assert U.pachner(getattr(U, GET[c])(i))
                u = U.isoSig_LockFree()
                if u in par: continue
                par[u] = s
                if u == b:
                    chain = [u]
                    while par[chain[-1]] is not None: chain.append(par[chain[-1]])
                    chain.reverse(); steps = []
                    for x, y in zip(chain, chain[1:]):
                        m = single_pachner(x, y); assert m is not None; steps.append((x, m[0], m[1], y))
                    return steps
                objs.append((U, u))
    return None

if __name__ == '__main__':
    src, key, out = sys.argv[1], sys.argv[2], sys.argv[3]
    steps = json.load(open(src))[key]; res = []; t0 = time.time(); conv = 0; how = {}
    for k, (a, code, face, b) in enumerate(steps):
        if code.startswith('P'): res.append((a, code, face, b)); continue
        path = None
        for radius, h, lim in ((1, 0, 20000), (1, 2, 50000), (2, 0, 50000), (2, 2, 100000), (3, 2, 200000)):
            path = local_bfs(a, code, face, b, radius, h, lim)
            if path is not None: break
        if path is None:
            na = regina.Triangulation4.fromIsoSig(a).size(); path = bibfs(a, b, na + 2, max_nodes=400000); radius = 'global'
        assert path is not None, f'step {k}: no Pachner path for {code}'
        res += path; conv += 1; how[str(radius)] = how.get(str(radius), 0) + 1
        if conv % 25 == 0: print(f'  {conv} converted (step {k}/{len(steps)}) {how} [{time.time()-t0:.0f}s]', flush=True)
    for a, code, i, b in res:                       # full re-check of the output
        T = regina.Triangulation4.fromIsoSig(a); assert T.pachner(getattr(T, GET[code])(i), True, True) and T.isoSig() == b
    for s1, s2 in zip(res, res[1:]): assert s1[3] == s2[0]
    from collections import Counter
    json.dump({'start': res[0][0], 'end': res[-1][3], 'steps': res}, open(out, 'w'))
    print(f'DONE: {conv} non-Pachner steps converted {how}; pure Pachner path {len(res)} moves {dict(Counter(s[1] for s in res))}; '
          f'{res[0][0]} -> {res[-1][3]} [{time.time()-t0:.0f}s]', flush=True)
