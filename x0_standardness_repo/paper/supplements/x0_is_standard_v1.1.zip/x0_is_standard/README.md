# X0 is standard: G6 is PL homeomorphic to S⁴ (v1.1)

**Claim.** The 6-pentachoron census triangulation

```
G6 = gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa
```

is PL homeomorphic to the standard 4-sphere. Combined with the accepted certificate X0 ≅_PL G6 (`x0_census_reduction_v2`, accepted by the analyst as `x0_to_G6_verified_v1`), it follows that

**X0 = Σ2(S⁴, τ⁰ρ¹ P(−2,3,7)) is PL homeomorphic, and hence diffeomorphic, to S⁴.**

The smooth conclusion holds because a compact PL 4-manifold has a compatible smoothing that is unique up to diffeomorphism. This answers Hughes–Kim–Miller Question 1.4. The standing premises are listed under "Trust and premises" below.

**Changes from v1.0.** The certificate file is byte-for-byte unchanged (SHA-256 `e9ba9f14…adcdf`). The verifier now uses explicit checks instead of `assert`, so `python -O` cannot disable them. It also checks face ranges, legality, size changes and the certificate hash, and rebuilds the double of a 4-simplex from scratch. Several statements in this README have been corrected; see "Corrections" at the end.

## Verify (about 20–45 s, any platform)

```sh
pip install regina==7.4.1
python3 verify_x0_standard.py x0_standard_certificate.json        # exit status 0 = pass
```

There is no randomness. Every step starts from a canonical triangulation `fromIsoSig(state)`, performs one guarded Regina move on a named face, and must produce the next state's isoSig exactly.

The analyst's audit package (`x0_standardness_audit_v1`) contains two further independent checkers: a full replay that shares no code with this one, and a second implementation of the 2-0 moves that does not call Regina's move. Both pass. A separate differential test (`two_zero_differential_test`) found no disagreement between that second implementation and Regina on 125,703 degree-2 faces.

| Path | Moves | Move types |
|---|---:|---|
| G6 → W = `gLAMPQaccddefefffaaaubaaMafapboapboa` (key `X`) | 6,814 | 3-3 (5,830), 2-4 (492), 2-0 edge (417), 2-0 triangle (75) |
| std6 = `gLAPPQacbedeeffffaaawaaaobcacaQbPboa` → W | 1,519 | 3-3 (1,315), 2-4 (102), 2-0 edge (81), 2-0 triangle (21) |
| S⁴₂ = `cPkbbbbaaaaaaaa` → std6 | 103 | **Pachner only**: 3-3 (80), 2-4 (14), 4-2 (6), 5-1 (3) |

S⁴₂ is two 4-simplices with corresponding facets glued by the identity (the double of a 4-simplex; also Regina's `Example4.sphere()`), which is the standard S⁴. So G6 ≅ W ≅ std6 ≅ S⁴₂.

## How it was found

The search statistics here are discovery data, not part of the proof.

1. **Reproduce the census classifier.** `provenance/burke_walk.py` is a port of the random walk in Burke–Burton–Spreer's `Dim4Census/main.cc` (`perform` / `step`). It uses 3-3, 2-4 and 2-0 moves, edge collapse and 1-5, with sizes biased to about 9 pentachora, and stops at any triangulation with 2 vertices and 6 pentachora. `chain.py` chains these walks. (It imports from a fixed path under `/home/claude`; edit that line to rerun elsewhere.)
2. **Run it from three starts.** Four minutes each, giving the distinct 2-vertex, 6-pentachoron triangulations reached (`provenance/chain_summaries.json`):

   | Start | Distinct reached | Behaviour in the run |
   |---|---:|---|
   | Standard control | 39,198 | still growing |
   | Q-class control (Q plus one 2-4 move) | 230 | no new triangulations after 230 (an observed plateau, not a proof that the class is closed) |
   | X0 (G6) | 37,009 | still growing |

   The X0 and standard chains share **21,970** triangulations.
3. **Shorten the meeting paths.** The paths to one shared triangulation W (769,617 and 475,734 raw moves, kept in `provenance/raw_meeting_paths.json.gz`) were shortened. Loop erasure (`loop_erase.py`) and then a shortest path in the graph of visited states (`shortest.py`) give the certified paths above. Each step is re-derived as one move on a canonical triangulation.
4. **Convert the standard end to Pachner moves.** The short path from the 2-pentachoron sphere was converted to pure Pachner moves (`pachnerize.py`).

## Trust and premises

- **Admissible 2-0 moves preserve PL type.** An edge or triangle 2-0 move removes a two-pentachoron pillow around a degree-2 face and identifies its outer facets in pairs. Regina's guard requires the face to be valid, interior and of degree 2 in two distinct pentachora, its link to be the double of a simplex, and the faces identified by the flattening to form no closed chain. Under these conditions the local replacement preserves the PL homeomorphism type of the manifold. The flattening map itself is not a homeomorphism, and degree two alone is not sufficient. Burke–Burton–Spreer introduce these moves among local modifications expressible by Pachner sequences and use them in their PL classifier.
- **Pure Pachner conversion is partial and optional.** On an earlier version of these paths, every 2-0 step we tried (44 steps) was replaced by 2–12 Pachner moves without growing the triangulation; the conversion was stopped only because it was slow. Some bounded local searches failed to find replacements, but they were not exhaustive and prove nothing. A Pachner-only certificate looks feasible with more CPU time. It is not needed for the PL conclusion.
- **Premises inherited from X0 → G6.** These are the analyst's construction identification (source pair and cap geometry), the Regina `simplify()` macros in the punctured step (pinned to linux/amd64), and the capping argument. All were accepted earlier.
- **Software.** Regina 7.4.1's guarded moves, skeleton and isoSig canonical forms. The second 2-0 implementation in the audit shares Regina's isoSig codec, skeleton and simplex construction.

## Corrections to v1.0

- v1.0 said that squashing the pillow "is a PL homeomorphism". The flattening map is not a homeomorphism; the correct statement is that the admissible local replacement preserves the ambient PL type (see above).
- v1.0 described the Q-class control as "a small closed class". It is an observed plateau in a four-minute run.
- v1.0 said some 2-0 steps have "no Pachner replacement even with 2 extra pentachora" and called this a height barrier. Those were non-exhaustive bounded searches and support no such conclusion. v1.0 also called the triangulations involved "singular"; they are generalized triangulations of manifolds.
- v1.0's verifier ran its checks inside `assert`, which `python -O` removes. Fixed in v1.1.
- v1.0 justified the smooth conclusion as "PL = DIFF in dimension 4". The precise reason is existence and uniqueness of compatible smoothings of PL 4-manifolds.
