#!/usr/bin/env python3
"""Verify:  G6 (census 6-pentachoron triangulation of X0)  ~PL  standard S^4.
Certificate = three forward move paths on canonical triangulations:
  (1) G6            -> X   (Pachner 3-3, 2-4 and guarded 2-0 edge/triangle moves)
  (2) std6          -> X   (same move types)
  (3) S^4_2 = cPkbbbbaaaaaaaa (Regina's Example4.sphere(), the double of a 4-simplex) -> std6 (Pachner moves only)
Each step (a, code, i, b): T = fromIsoSig(a); perform the guarded Regina move `code` on face i of T; require that
the move is accepted and that T.isoSig() == b.  Consecutive steps must chain.  Every move is a PL homeomorphism
(Pachner moves: bistellar; 2-0 moves: squashing a two-pentachoron pillow, which Regina's guards certify).
Hence G6 ~ X ~ std6 ~ S^4_2, i.e. G6 and X0 are PL (hence smoothly) standard."""
import json, sys, regina, warnings
warnings.filterwarnings('ignore')
FACE = {'P0': 'vertex', 'P1': 'edge', 'P2': 'triangle', 'P3': 'tetrahedron', 'P4': 'pentachoron', 'Z1': 'edge', 'Z2': 'triangle'}
def move(T, code, i):
    f = getattr(T, FACE[code])(i)
    return T.pachner(f, True, True) if code[0] == 'P' else T.twoZeroMove(f, True, True)
def check(steps, start, end, label):
    from collections import Counter
    assert steps[0][0] == start and steps[-1][3] == end, label + ': endpoints'
    for k, (a, code, i, b) in enumerate(steps):
        T = regina.Triangulation4.fromIsoSig(a)
        assert move(T, code, i) and T.isoSig() == b, f'{label}: step {k} fails'
        if k: assert steps[k - 1][3] == a, f'{label}: chain broken at {k}'
    print(f'PASS {label}: {len(steps)} moves {dict(Counter(s[1] for s in steps))}')
if __name__ == '__main__':
    C = json.load(open(sys.argv[1]))
    G6 = regina.Triangulation4.fromIsoSig('gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa').isoSig()
    S2 = regina.Example4.sphere().isoSig(); assert S2 == 'cPkbbbbaaaaaaaa'
    check(C['G6_to_X'], G6, C['X'], 'G6 -> X')
    check(C['std6_to_X'], C['std6'], C['X'], 'std6 -> X')
    check(C['sphere_to_std6'], S2, C['std6'], 'S^4_2 -> std6 (pure Pachner)')
    print('ALL PASS: G6 is PL homeomorphic to the standard 4-sphere; with the accepted X0 -> G6 certificate, X0 is standard.')
