# X0 is standard: G6 is PL homeomorphic to S⁴

**Claim.** The 6-pentachoron census triangulation

```
G6 = gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa
```

is PL homeomorphic to the standard 4-sphere. Combined with the accepted certificate X0 ≅_PL G6 (`x0_census_reduction_v2`, accepted by the analyst as `x0_to_G6_verified_v1`), it follows that

**X0 = Σ2(S⁴, τ⁰ρ¹ P(−2,3,7)) is PL homeomorphic, and hence diffeomorphic, to S⁴.**

Smoothness follows because PL = DIFF in dimension 4. This answers Hughes–Kim–Miller Question 1.4 for P(−2,3,7). The standing premises are listed under "Trust and premises" below.

## Verify (about 20 s, any platform)

```sh
pip install regina==7.4.1
python3 verify_x0_standard.py x0_standard_certificate.json
```

There is no randomness. Every step starts from a canonical triangulation `fromIsoSig(state)`, performs one guarded Regina move on a named face, and must produce the next state's isoSig exactly.

| Path | Moves | Move types |
|---|---:|---|
| G6 → X = `gLAMPQaccddefefffaaaubaaMafapboapboa` | 6,814 | 3-3 (5,830), 2-4 (492), 2-0 edge (417), 2-0 triangle (75) |
| std6 = `gLAPPQacbedeeffffaaawaaaobcacaQbPboa` → X | 1,519 | 3-3 (1,315), 2-4 (102), 2-0 edge (81), 2-0 triangle (21) |
| S⁴₂ = `cPkbbbbaaaaaaaa` → std6 | 103 | **Pachner only**: 3-3 (80), 2-4 (14), 4-2 (6), 5-1 (3) |

S⁴₂ is Regina's `Example4.sphere()`, two pentachora glued along their boundaries (the double of a 4-simplex), which is the standard S⁴. So G6 ≅ X ≅ std6 ≅ S⁴₂.

## How it was found

1. **Reproduce the census classifier.** `provenance/burke_walk.py` is a line-by-line port of the random walk in Burke–Burton–Spreer's `Dim4Census/main.cc` (`perform` / `step`). It uses 3-3, 2-4 and 2-0 moves, edge collapse and 1-5, with sizes biased to about 9 pentachora, and stops at any triangulation with 2 vertices and 6 pentachora. `chain.py` chains these walks.
2. **Run it from three starts.** Four minutes each, giving the distinct 2-vertex, 6-pentachoron triangulations reached (`provenance/chain_summaries.json`):

   | Start | Distinct reached | Behaviour |
   |---|---:|---|
   | Standard control | 39,198 | still growing |
   | Q-class control (Q plus one 2-4 move) | 230 | saturated: a small closed class, as in the census |
   | X0 (G6) | 37,009 | still growing |

   The X0 and standard chains share **21,970** triangulations.
3. **Shorten the meeting paths.** The paths to one shared triangulation X (769,617 and 475,734 raw moves, kept in `provenance/raw_meeting_paths.json.gz`) were shortened. Loop erasure (`loop_erase.py`) and then a shortest path in the graph of visited states (`shortest.py`) give the certified paths above. Each step is re-derived as one move on a canonical triangulation.
4. **Convert the standard end to Pachner moves.** The short path from the 2-pentachoron sphere was converted to pure Pachner moves (`pachnerize.py`), including its three edge collapses.

## Trust and premises

- **2-0 moves are PL homeomorphisms.** For a face σ of degree 2, the two pentachora around σ form a pillow, a 4-ball of the form σ ∗ (two (3−k)-simplices glued along their boundaries). Regina's guards require this configuration to be genuine. The move squashes the pillow onto a 3-ball, which is a PL homeomorphism supported near the pillow. The inverse cuts along a properly embedded 3-ball and inserts a lens. The census's own PL classes are defined with this same move set, and the accepted X2 certificate used 2-0 moves inside `simplify()`.
- **Pure Pachner conversion is partial.** Most 2-0 steps convert to 2–6 Pachner moves locally (`localize.py`). Some 2-0 steps in very small singular triangulations have no Pachner replacement even with 2 extra pentachora of room; this is the height-barrier phenomenon the census describes. So a pure-Pachner version of the G6 → X and std6 → X paths would need larger searches. It is not needed for the PL conclusion.
- **Premises inherited from X0 → G6.** These are the analyst's construction identification (source pair, relative PL normal-neighbourhood theorem), the Regina `simplify()` macros in the punctured step (pinned to linux/amd64), and the capping argument. All were accepted earlier.
- **Software.** Regina 7.4.1's implementations of the guarded moves and of isoSig canonical forms.

## Recommended before any announcement

- An independent re-verification by the analyst, ideally with a second implementation of the 2-0 move guards.
- If possible, a check with Burke–Burton–Spreer that G6's class is their standard class. Their own classifier, run on the census, should merge it the same way.
