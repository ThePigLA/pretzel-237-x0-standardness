#!/usr/bin/env python3
"""Verify byte identities and the interface with the accepted X0-to-G6 result.

This checks completed receipts and the exact capped endpoint. It does not
re-execute the earlier geometric construction or its large reduction traces.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile
import regina

G6 = 'gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa'
ARCHIVE_SHA256 = '22d25e6d33def97cf706e0a4db7a2777c7325e7a6fcb91f14e5d30867224ba06'
PRIOR_SHA256 = '87689c339268b5cdcfd501fa693a8ce22f3a1865083243256799ced104d2764e'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def main():
    root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'refusing to overwrite a receipt')
    original = root/'input/x0_is_standard.zip'
    require(digest(original) == ARCHIVE_SHA256, 'uploaded archive hash mismatch')
    payloads = 0
    with zipfile.ZipFile(original) as archive:
        require(archive.testzip() is None, 'uploaded archive CRC failure')
        for member in archive.infolist():
            if not member.is_dir():
                require(archive.read(member) == (root/'source'/member.filename).read_bytes(),
                        'reviewer payload modified: ' + member.filename)
                payloads += 1
    status_path = root/'prior/X0_to_G6_STATUS.json'
    require(digest(status_path) == PRIOR_SHA256, 'accepted prior status hash mismatch')
    prior = read(status_path)
    require(prior['status'] == 'ACCEPTED_X0_PL_HOMEOMORPHIC_TO_G6', 'wrong prior status')
    require(prior['G6']['isoSig'] == G6, 'wrong prior endpoint')
    bindings = {
        'prior_state/candidate/GEOMETRIC_CONSTRUCTION_ADMISSION.json':
            root/'prior/GEOMETRIC_CONSTRUCTION_ADMISSION.json',
        'native/replay/independent_replay.json': root/'prior/native_replay_receipt.json',
    }
    for old_name, copied_path in bindings.items():
        require(digest(copied_path) == prior['evidence_sha256'][old_name],
                'prior evidence hash mismatch: ' + old_name)
    geometry = read(bindings['prior_state/candidate/GEOMETRIC_CONSTRUCTION_ADMISSION.json'])
    require(geometry['result'] == 'PASS', 'geometric admission did not pass')
    require(geometry['parameters']['twist'] == 0 and geometry['parameters']['roll'] == 1,
            'wrong twist/roll identification')
    require(geometry['parameters']['knot'] == 'oriented P(-2,3,7)', 'wrong source knot')
    require(geometry['immutable_marked_master']['file_sha256'] ==
            prior['X0']['marked_master_sha256'], 'master identity mismatch')
    native = read(bindings['native/replay/independent_replay.json'])
    require(native['status'] == 'PASS', 'prior native replay did not pass')
    capped = read(root/'prior/capped_G6.json')
    require(capped['isoSig'] == G6 and capped['simplex_count'] == 6, 'wrong capped endpoint')
    rows = capped['numbered_rows']
    require(len(rows) == 6 and all(len(row) == 5 for row in rows), 'bad capped facet-pairing shape')
    t = regina.Triangulation4()
    t.newPentachora(6)
    equations = 0
    for i, row in enumerate(rows):
        for f, record in enumerate(row):
            j, encoded = record
            require(type(j) is int and 0 <= j < 6 and
                    isinstance(encoded, str) and sorted(encoded) == list('01234'),
                    'invalid facet-pairing record')
            p = tuple(map(int, encoded))
            back_index, back_encoded = rows[j][p[f]]
            q = tuple(map(int, back_encoded))
            require(back_index == i and all(q[p[k]] == k for k in range(5)),
                    'nonreciprocal facet pairing')
            if t.pentachoron(i).adjacentSimplex(f) is None:
                t.pentachoron(i).join(f, t.pentachoron(j), regina.Perm5(*p))
            equations += 1
    require(t.isoSig() == G6, 'actual prior facet pairing differs from the new start')
    certificate_path = root/'source/x0_is_standard/x0_standard_certificate.json'
    certificate = read(certificate_path)
    require(certificate['G6_to_X'][0][0] == t.isoSig(), 'new path starts at a different triangulation')
    main_receipt = read(root/'audit/independent_replay_receipt.json')
    zero_receipt = read(root/'audit/INDEPENDENT_TWO_ZERO.json')
    require(main_receipt['status'] == zero_receipt['status'] == 'PASS', 'new audit failed')
    for receipt in (main_receipt, zero_receipt):
        require(receipt['certificate_sha256'] == digest(certificate_path), 'new certificate hash mismatch')
    require(main_receipt['verifier_sha256'] == digest(root/'audit/independent_replay.py'),
            'independent replay checker changed after execution')
    require(zero_receipt['checker_sha256'] == digest(root/'audit/independent_two_zero.py'),
            '2-0 checker changed after execution')
    result = {
        'status': 'PASS',
        'schema': 'x0-standardness-dependency-binding-v1',
        'original_uploaded_archive_sha256': ARCHIVE_SHA256,
        'unchanged_reviewer_payloads': payloads,
        'accepted_prior_status_sha256': PRIOR_SHA256,
        'marked_master_sha256': prior['X0']['marked_master_sha256'],
        'prior_G6_gluing_equations_checked': equations,
        'exact_old_endpoint_equals_new_start': True,
        'endpoint': G6,
        'new_replay_receipt_sha256': digest(root/'audit/independent_replay_receipt.json'),
        'independent_two_zero_receipt_sha256': digest(root/'audit/INDEPENDENT_TWO_ZERO.json'),
        'scope': 'Binds completed new verification to the previously accepted construction and X0-to-G6 equivalence; does not rerun earlier heavy geometry or reductions.'
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
