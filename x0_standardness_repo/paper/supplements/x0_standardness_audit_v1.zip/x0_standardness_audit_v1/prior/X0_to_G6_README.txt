X0 TO THE SIX-PENTACHORON CENSUS TRIANGULATION G6
===============================================

Accepted result
---------------
The original marked X0 master for J=P(-2,3,7), twist m=0 and roll n=1 is
PL-homeomorphic, as an underlying unmarked manifold, to

    G6 = gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa.

The complete reviewer certificate has been audited and independently replayed.
The capping verification has been strengthened to check an explicit boundary
homeomorphism. This package does NOT prove that G6 or X0 is PL-standard and
does not settle Hughes-Kim-Miller Question 1.4. It does turn that question, for
the previously accepted marked construction, into standardness of this exact
six-pentachoron triangulation. X2 remains accepted as PL-standard.

Authoritative result: CURRENT_STATUS.json.
Exact native endpoint: native/replay/capped_G6.json.
The pentachoron count here refers to a generalized triangulation, allowing
face identifications, rather than a six-facet abstract simplicial complex.

What was actually checked
-------------------------
1. All 21 reviewer payloads are retained unchanged, bound to the uploaded
   x0_census_reduction.zip (SHA256 below). The six reused source/contraction
   files and the vertex-link certificate agree byte for byte with the prior
   accepted X0 release and its pinned manifest.

2. The X0/X2 comparison confirms 100,736 common facets, with exactly 3,008
   cap facets removed and 3,008 inserted. Vertex labels, deck map, branch and
   twin spheres are identical. All noncap parts remain identical.

3. All 4,310 links of the 103,744-facet X0 master reduce to the boundary of a
   four-simplex through 529,460 checked three-dimensional bistellar moves.
   This admits the source as a closed combinatorial four-manifold without
   relying on Regina's manifold recognition.

4. All 3,308 original full-link contractions replay to 44,620 facets.

5. The new 629,874 moves all replay: 957 full-link contractions, 50,016
   2-to-4 flips, 517,325 3-to-3 flips and 61,576 4-to-2 flips. The endpoint
   has 1,332 facets and 45 vertices, with f=(45,795,2750,3330,1332).
   Its ordered facets and every native gluing agree exactly with the macro
   source. All 3,330 pairing records / 6,660 half-facets are checked.

6. Removing embedded simplex 25, with vertices [3,19,419,504,918], gives
   1,331 pentachora. The first native simplify reaches 51. All 5,173 macro
   hashes and 54,563 explicit guarded 2-to-4 kicks replay, ending at

       T5 = fHMLQcabcdeeeecanbpaoazaobWbGb

   with five pentachora. The certificate explicitly has ball=false.

7. The actual boundary of T5 is explicitly isomorphic to the standard
   one-tetrahedron S3, bkaagj. We attach its cone by a checked boundary
   isomorphism. Both boundary embeddings preserve and reflect all ordered
   affine subface identifications. Both sides embed in the union and meet
   precisely in that boundary. In every dimension the counts satisfy

       (1,2,10,13,5) + (2,3,4,3,1) - (1,2,2,1,0)
       = (2,3,12,15,6).

   The union is exactly isomorphic to G6; all thirty paired half-facet
   equations are checked. No simplification is performed after capping.

The elementary audit took 62.7 seconds here, and the independent native/cap
replay took 170.8 seconds. These are observed component timings on the recorded
Linux environment, not universal runtime guarantees. The native stage used
Regina distribution 7.4.1, API version 7.4, Python 3.12.14, x86_64 Linux.
The engine SHA256 and execution resources are in its receipt.

Why the cap is enough
---------------------
Write C for the closed 1,332-facet source. The moves prove

    C minus an open embedded four-simplex  PL-homeomorphic to T5.

The removed simplex is a PL ball. The new cap is also a PL ball because it is
the cone over the explicitly recognized PL three-sphere. A PL boundary map
between these ball boundaries extends over the balls by coning after suitable
subdivision. Consequently replacing the old cap by the new one does not change
the closed PL type, giving X0 =_PL C =_PL G6.

This argument does not assume that T5 is a PL ball and does not invoke a
four-dimensional Schoenflies assertion. Native boundary shellings can change
the boundary mesh; a pointwise fixed original boundary triangulation is not
claimed. Deck, branch and twin markings are not transported through the
unmarked reduction.

Short direct fundamental-group proof at G6
------------------------------------------
The endpoint's two vertices and three edges have spanning-tree edge 1.
Edges 0 and 2 give generators a and b. The twelve triangle relations, in
the recorded order, are

    a^-1, b, a^-2 b^-1, a, a^-1, b a^2,
    a, a, a^-1, a, a^-1, a.

The first relation kills a and the second kills b. The complete two-skeleton,
all sixty triangle embeddings and both elementary Tietze eliminations are
checked in standard-library Python, with no native group simplification in
the proof. The acceptance combiner checks all thirty gluing equations linking
this exact skeleton to the capped endpoint. Thus pi1(G6)=1 directly; together
with the closed oriented manifold premise and chi=2 this also gives the
homology and homotopy type of S4. PL-standardness is the remaining question.

Public census and the role of Q
------------------------------
The full census file is included with its pinned public Git identity:

  repository  https://github.com/raburke/Dim4Census
  commit      375f7581630d8e34da5461127e3fb9fe25339cb7
  file        Census/6p-closedOrientable.esig
  blob        645e402db4f38f4460ccfc35a43a1dd2f4077b62
  SHA256      fdc95d18b0ec32a62face1740cbf65e0fdad0ac1b561d72e3ffe487815921d4c

G6 occurs exactly once, at one-based line 187,210 (zero-based index 187,209).
Its classic and edge-degree signatures are equal. The checked public materials
do not give its computational class label or a path to a representative.

The paper's exceptional four-pentachoron Q has exactly the signature in our
previously accepted Q work: eAMPcaabcddd+aoa+aAa8aQara. With that accepted proof
as a dependency, any certified path from G6 to two or four pentachora suffices.
A path to exact Q or to a known standard sphere of any size also suffices.
The current X0-to-G6 equivalence does not depend on Q's standardness proof.

An independent permutation search confirms that this presentation of G6 has
no copy of the particular two-pentachoron complex cHIbbb0bRbpb. That fact is
combinatorial, not a PL invariant: it does not rule out a path to Q, a later
presentation displaying that subcomplex, or a different geometric proof.
See census/CENSUS_AUDIT.txt for precise scope and source details.

Corrections to the search conclusions
--------------------------------------
* Closed four-dimensional triangulations have an even number of pentachora.
  Starting with six, heights 4 and 5 allow the same size levels through ten.
  Height 6, through twelve, is the next genuinely larger closed search bound.

* Regina 7.4.1 simplifyExhaustive omits 5-to-1 moves. The reviewer's claimed
  through-ten negative search has no transcript in the supplied ZIP and has
  not been independently certified here as a full all-five-move neighborhood.

* Our separate all-five-move search through EIGHT is complete: 1,247 states,
  comprising thirteen six-pentachoron and 1,234 eight-pentachoron states.
  A second pass checks every parent path and every bounded legal neighbor.
  No smaller endpoint is in that component. This is a finite search result,
  not evidence of an exotic sphere.

* The attempted extension through TEN encountered a malformed SQLite
  checkpoint and stopped. Its outcome is a storage error, not exhaustion.
  The corrupted database is excluded from this deliverable. Search code is
  included for inspection and further development; larger checkpoint storage
  has not been validated on this workspace. The separate max-eight database
  and closure proof passed their checks. See search/SEARCH_STATUS.json and
  search/README_SEARCH.txt for exact resources and failure evidence.

The most useful external datum is G6's class representative together with a
replayable path or recorded chain of class merges. A label by itself is not
a standardness certificate. No correspondence with the census authors was
sent as part of this audit.

Reproduction
------------
From the extracted directory, using the compatible Linux Regina environment:

    python3 -E -B verify_chain.py --output verification

For just the elementary source-to-1,332 proof, with ordinary Python:

    python3 -E -B verify_chain.py --elementary-only --output verification_python

For file integrity without re-executing mathematics:

    python3 -E -B verify_chain.py --bindings-only

For the tiny independent endpoint group proof, also ordinary Python:

    python3 -E -B endpoint/g6_group_certificate.py verify \
      --certificate endpoint/g6_two_skeleton_and_group.json \
      --receipt group_replay_fresh.json

Outputs must be fresh paths. The wrapper preserves the frozen input files,
keeps assertions enabled and reaps child processes when interrupted. The
individual mathematical stages were run for this audit; the orchestration
wrapper was reviewed and its bindings, relocation and cancellation behavior
checked without redundantly rerunning the large native trace.

The reviewer verify_all.sh is retained unchanged. The analyst wrapper avoids
its fixed /tmp output and supplies stricter schema and capping checks. The
reviewer's search producer has an import-name mismatch (reduce2 versus the
shipped reduce2_producer.py); it is not needed for certificate replay. Its
resume preserves a durable logged prefix but reseeds future random choices,
so it does not preserve an uninterrupted future trajectory in general.

Package structure and inherited evidence
-----------------------------------------
reviewer/ contains all reviewer payloads unchanged.
original_X0_binding/ contains selected original source files and the original
full manifest solely for byte comparison. It is explicitly a selected subset,
not a replacement for the complete original X0 construction release.
prior_state/ retains accepted construction/group/X2 status receipts and the
identity of the prior Q dependency. Heavy source geometry was not rerun here.
simplicial/, native/, endpoint/ and census/ contain the executed audits.
search/ contains the verified max-eight search and the larger-run failure
record. CURRENT_STATUS.json is the accepted mathematical project state;
search/SEARCH_STATUS.json describes the separate search experiment.

accept.py combines completed, hash-bound evidence. It does not execute the
proof traces; verify_chain.py does. Running accept.py again updates its status
timestamp and is unnecessary for checking this frozen package.

Original accepted X0 release:
https://chatgpt.com/library?file_id=libfile_84fca765242c819182b0d5b09a464da2&account_id=personal
Previously accepted Q certificate:
https://chatgpt.com/library?file_id=libfile_5c8dc290475481918da09fa701e5cef3&account_id=personal

Uploaded reviewer ZIP SHA256:
ef96bd165f2b177138a7b97a7bbba984bc4596c7564c7fff643df0007702c0e5

Primary external references
---------------------------
Hughes-Kim-Miller, Question 1.4:
https://arxiv.org/pdf/2402.11706
Burke-Burton-Spreer, SoCG 2025:
https://drops.dagstuhl.de/storage/00lipics/lipics-vol332-socg2025/html/LIPIcs.SoCG.2025.28/LIPIcs.SoCG.2025.28.html
Burke-Burton-Spreer, full version v2, 13 May 2026:
https://arxiv.org/pdf/2412.04768v2
Regina 7.4.1 native moves, simplify and exhaustive-search documentation:
https://regina-normal.github.io/engine-docs/classregina_1_1Triangulation_3_014_01_4.html
