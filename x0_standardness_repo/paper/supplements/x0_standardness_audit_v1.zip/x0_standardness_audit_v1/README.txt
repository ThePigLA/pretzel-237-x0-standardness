X0 STANDARDNESS: INDEPENDENT ACCEPTANCE AUDIT
==========================================

Result
------
The new certificate independently replays and establishes

  G6 = gAMLMQaabcdeffff2a+a2avbmaoaxaOb0aUa  =_PL  S4.

Composed with the previously accepted identification and X0-to-G6 reduction,
this establishes that X0 = Sigma_2(tau^0 rho^1 P(-2,3,7)) is PL-homeomorphic
to the standard S4. Compatible smoothings in dimension four are unique up to
diffeomorphism, so this also establishes smooth standardness. The identified
manifold is exactly the object in Hughes-Kim-Miller Question 1.4.

CURRENT_STATUS.json records the new acceptance. This is an acceptance audit
of a computer-assisted proof with explicit software and inherited construction
dependencies, not a formal proof-assistant certificate.

The result concerns the underlying unmarked four-manifold. It does not
standardize the branch knot or the covering involution.

What was newly verified
-----------------------
Three paths meet at X = gLAMPQaccddefefffaaaubaaMafapboapboa:

  G6 -> X          6,814 checked moves; maximum 22 pentachora; 2 vertices.
  std6 -> X        1,519 checked moves; maximum 16 pentachora; 2 vertices.
  S4_2 -> std6       103 checked moves; maximum 14 pentachora; 2-5 vertices.

Here std6 = gLAPPQacbedeeffffaaawaaaobcacaQbPboa and
S4_2 = cPkbbbbaaaaaaaa. The independent checker constructs S4_2 from two
abstract four-simplices glued on all corresponding boundary facets by the
identity. It verifies its signature and its agreement with Example4.sphere().

The three paths contain 8,436 moves: 7,842 Pachner and 594 two-zero moves.
Move counts: 5-1:3; 4-2:6; 3-3:7,225; 2-4:608;
edge two-zero:498; triangle two-zero:96. There are no edge collapses in the
final certificate. Only the 103-move standard-anchor segment is Pachner-only.

audit/independent_replay.py imports none of the reviewer's checker or search
code. It validates the pinned certificate bytes, schema, endpoint constants,
canonical states, every face index and allowed move, continuity, basic face
degree and incidence conditions, separate guarded legality queries, the
executed move, exact size changes, and every next-state signature. It checks
all 8,435 distinct states valid, closed, connected, orientable, and chi=2.
The complete replay ran under Python -O in 28.409 seconds here.

audit/independent_two_zero.py is a second implementation of the 594 two-zero
steps. It does not call move20, has20, or twoZeroMove. It checks the doubled
link and the relevant identification forests, and independently rebuilds the
surviving facet pairings. All 594 exact output signatures match. This check
ran under Python -O in 2.179 seconds here.

audit/verify_bindings.py confirms all 12 reviewer payloads are unchanged,
binds the prior accepted construction and reduction receipts by SHA256,
reconstructs the prior capped G6 from its actual facet pairings, checks all
30 reciprocal gluing equations, and requires exact agreement with the new
certificate's start. The earlier heavy geometry and reduction were not rerun.

These timings are observations on the recorded environment, not guarantees
for every machine. The executed environment used Python 3.12.14 and the
Regina 7.4.1 Python distribution (engine reports 7.4).

Why the two-zero moves are sufficient
------------------------------------
Burke-Burton-Spreer, Section 2.2, explicitly treats edge and triangle two-zero
moves as local modifications expressible by Pachner sequences. Regina's
guarded operation tests the local conditions needed for preservation of the
manifold. The additional checker verifies those conditions and the resulting
facet pairing separately for all two-zero moves in this certificate.

A complete displayed Pachner expansion is not required for this PL conclusion.
The maximum of 22 is a bound for the supplied mixed-move paths; no bound of
22 is asserted for an expanded Pachner-only path.

The README's statement that flattening a four-ball onto a three-ball "is a
PL homeomorphism" should be replaced by: the admissible local replacement
preserves the ambient PL-manifold. The quotient flattening map itself is
dimension-lowering and is not that homeomorphism. Degree two alone is also
not a sufficient admissibility condition; the link and identification guards
are essential. See audit/two_zero_semantics.txt for the detailed audit.

Relation to the previous searches
--------------------------------
The final G6 path first exceeds ten pentachora after move 37, reaching twelve,
and eventually reaches twenty-two. It uses two-zero shortcuts as well.
It is therefore consistent with the earlier negative all-five-Pachner search
through ten. The certificate is a positive finite proof, independent of the
discovery walk's success rates, explored-state counts, or completeness.

The old 53,058-entry set remains a correctly certified standard subset from
the narrow six-cell bootstrap pass. It was not a complete listing of every
standard census sphere. The new certificate extends our standardness evidence
to G6 and, via the previously established connections, the supplied 26.

The 26 have degree profiles (1,29):20, (2,28):4, (3,27):2; all vertex 5-1
queries are false. Here degree counts pentachoron-vertex incidences with
multiplicity in a generalized triangulation. Those degree counts describe
why no immediate 5-1 was available; they are not PL invariants.

The new result does not depend on the separate proof that Q is standard.
Nor does it require the census authors' unpublished historical group labels.
The paths establish standardness directly; recovering exactly which saved
group label the authors assigned G6 remains a separate metadata question.

Corrections to the reviewer's narrative
---------------------------------------
* A four-minute Q walk plateauing at 230 endpoints is an observed plateau,
  not an exhaustive closure proof.
* The final certificate's G6 maximum is 22; the earlier shortened path was
  reported to reach 24.
* The final complete certificate is not Pachner-only. Its 594 two-zero steps
  are admissible PL-preserving moves and pass the second checker.
* A failed bounded local Pachner conversion proves no global obstruction.
* The supplied verifier puts move execution inside assert. Its ordinary
  documented invocation passes, but Python -O disables those checks. Our
  independent verifier uses explicit failures and was tested with -O.
* The provenance scripts include absolute /home/claude paths. This affects
  reproduction of the discovery process, not the self-contained final replay.
* A new standardness proof lowers a published upper bound on PL types only
  when it joins previously distinct computational groups. No new numerical
  census-class count is claimed in this audit.

Reproduce the new checks on the Mac
-----------------------------------
Use the existing regina_env if it has Regina 7.4.1. Otherwise install that
version in a dedicated environment. No Docker is needed for these new checks.
From the extracted x0_standardness_audit_v1 directory, with fresh output names:

  python -O audit/independent_replay.py --output replay_on_mac.json

  python -O audit/independent_two_zero.py \
    source/x0_is_standard/x0_standard_certificate.json \
    --output two_zero_on_mac.json

  python -O audit/verify_bindings.py --output bindings_on_mac.json

The first command replays every new move. The second independently checks and
reconstructs every two-zero step. The third checks the immutable input bytes,
completed receipts, and the interface to the earlier accepted result. The
third does not rerun the earlier construction or its reduction traces.

The original reviewer's verification also passed under normal Python:

  python source/x0_is_standard/verify_x0_standard.py \
    source/x0_is_standard/x0_standard_certificate.json

Use the independent checker above for verification that also works under -O.

Package structure and dependencies
----------------------------------
input/x0_is_standard.zip is the original uploaded archive, unchanged.
source/x0_is_standard/ contains its 12 unchanged payloads.
audit/ contains the independent checkers, executed receipts, and review notes.
prior/ contains selected immutable prior acceptance records and the supplied
26. The old false/pending flags describe the historical state when those
receipts were made; CURRENT_STATUS.json supersedes them for project status.
MANIFEST_SHA256.json binds every payload in this new audit package.

This package is complete for replaying the new G6-to-standard bridge. The
earlier complete X0 construction and X0-to-G6 traces remain separate accepted
dependencies, rather than being duplicated here.

Accepted X0-to-G6 archive:
https://chatgpt.com/library?file_id=libfile_acde65dabf7081918b0d471ae107fc73&account_id=personal
Archive SHA256: 44c6c1e7c8498c929b956f3cd26df9eabf13667e2a6d4962a7d44bc497bc3f57

Original accepted marked X0 release:
https://chatgpt.com/library?file_id=libfile_84fca765242c819182b0d5b09a464da2&account_id=personal

Remaining software/mathematical dependencies
-------------------------------------------
Pachner execution, signature decoding/canonicalization, skeleton and validity
queries still use Regina. The separate two-zero checker does not remove all
Regina dependence: it uses the codec, skeleton, and simplex constructor.
The geometric identification of the original marked master and its previously
accepted reduction are inherited. This audit does not claim an independently
implemented entire topology engine, a fresh geometric construction audit, or
an explicit Pachner expansion for all two-zero steps.

Primary references
-------------------
Hughes-Kim-Miller, Branched covers of twist-roll spun knots and turned twisted
tori, Corollary 1.2 (J=P(-2,3,7)) and Question 1.4:
https://arxiv.org/html/2402.11706v3

Burke-Burton-Spreer, Small Triangulations of 4-Manifolds and the 4-Manifold
Census, Section 2.2 (two-zero moves) and Section 4.1 (classifier walk):
https://arxiv.org/html/2412.04768v2

Regina 7.4.1 API: move20 / twoZeroMove:
https://regina-normal.github.io/engine-docs/classregina_1_1detail_1_1TriangulationBase.html
Source tag regina-7.4.1, commit 219d658e5e51cc003807fc871fb3534a448a972f,
engine/triangulation/detail/moves-impl.h,
blob 92acb305836310ca7996956bd5979e29c765dfa1.

Friedl-Nagel-Orson-Powell, The foundations of four-manifold theory in the
topological category, NYJM Monographs 6 (2025), Theorem 3.5(2), pp.17-18:
https://nyjm.albany.edu/m/2025/6p.pdf
